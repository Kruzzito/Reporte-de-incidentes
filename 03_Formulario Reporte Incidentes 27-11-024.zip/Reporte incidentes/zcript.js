document.addEventListener("DOMContentLoaded", () => {
    const inputFecha = document.getElementById("fecha");
    const inputHora = document.getElementById("hora");

    const ahora = new Date();

    // Establece la fecha en formato YYYY-MM-DD
    const fechaActual = ahora.toISOString().split("T")[0];
    inputFecha.value = fechaActual;

    // Establece la hora en formato HH:MM (24 horas)
    const horaActual = ahora.toTimeString().split(":").slice(0, 2).join(":");
    inputHora.value = horaActual;
  });

        async function enviarFormulario(event) {
    event.preventDefault();

    const formulario = document.getElementById('formularioIncidentes');
    const formData = new FormData(formulario);

    const data = {};
    formData.forEach((value, key) => {
      data[key] = value;
    });

    const url = "https://script.google.com/macros/s/AKfycbzyRBx1VEalfLybo6HNPJHKpTg7NyOTJEK80w__EDwz0d2ikmvrF6N4O8oqZF9gcyMG/exec";

    try {
      const respuesta = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(data).toString()
      });

      if (respuesta.ok) {
        alert("Datos enviados exitosamente.");
        formulario.reset();
      } else {
        alert("Hubo un problema al enviar los datos.");
      }
    } catch (error) {
      console.error("Error al enviar los datos:", error);
      alert("Error al enviar los datos.");
    }
  }